Fields are optionally enclosed by " and terminated by \n

songs.csv [:id, :name, :artist_id, :genre_id, :csp]
	Contains the list of songs appearing in the co-occurrences.
	CSP (contiguous sequential patterns) is the sum of d1 (post-occurrences at distance 1) for this song (roughly, the popularity)
artist.csv [:id, :name, : csp]
	Contains the list of artists appearing in the co-occurrences.
	CSP is the sum of d1 for songs by this artist
genres.csv [:id, :name, : csp]
	Contains the list of artists appearing in the co-occurrences.
	CSP is the sum of d1 for songs in this genre
song_to_song.csv [:song_id, 'Song', :next_song_id, 'Song', false, :d1, :d2, :d3]
	Contains the pairs of songs/songs co-occurring in playlists.
	d1, d2, d3 count the times that next_song_id is the 1st/2nd/3rd song that follows song_id in a playlist
artist_to_artist.csv [:artist_id, 'Artist', :next_artist_id, 'Artist', false, :d1, :d2, :d3]
	Contains the pairs of artists/artists co-occurring in playlists.
	d1, d2, d3 count the times that any song by artist_id is the 1st/2nd/3rd song that follows any song by next_artist_id in a playlist

Note that artist_to_artist.csv is provided for convenience, but can be created from song_to_song.csv as follows:

Cooccurrence.all(:select => "s1.artist_id AS artist_id, s2.artist_id AS next_artist_id, SUM(d1) AS sum_d1, SUM(d2) AS sum_d2, SUM(d3) AS sum_d3", :include => [:predecessor, :successor], :joins => "INNER JOIN songs s1 ON predecessor_id = s1.id INNER JOIN songs s2 ON successor_id = s2.id",  :group => 's1.artist_id, s2.artist_id')
